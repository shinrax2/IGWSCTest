if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'InGameWaitingStatusColor',
		data = {
			modworkshop_id = 19670
		}
	})
end